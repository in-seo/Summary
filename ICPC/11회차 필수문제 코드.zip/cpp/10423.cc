#include <bits/stdc++.h>
using namespace std;
using ii = pair<int, int>;

int N, M, K, vis[1001];
struct P {
	int u, v, w;
	P() {}
	P(int u, int v, int w) :u(u), v(v), w(w) {}
	bool operator <(const P&rhs) const {
		return w < rhs.w;
	}
};
vector<ii> adj[1001];


int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
#endif
	ios_base::sync_with_stdio(false); cin.tie(0);
	cin >> N >> M >> K;
	for (int i = 0; i < K; i++) {
		int u; cin >> u;
		adj[0].push_back({ u,0 });
		adj[u].push_back({ 0,0 });
	}
	for (int i = 0; i < M; i++) {
		int u, v, w;
		cin >> u >> v >> w;
		adj[u].push_back({ v,w });
		adj[v].push_back({ u,w });
	}
	int ans = 0, cnt = 0;
	priority_queue<ii, vector<ii>, greater<ii>> pq;
	pq.push({ 0,0 });
	while (!pq.empty()) {
		while (!pq.empty() && vis[pq.top().second]) pq.pop();
		if (pq.empty()) break;
		int cur = pq.top().second;
		ans += pq.top().first; vis[cur] = 1;
		cnt++; pq.pop();
		for (auto&it : adj[cur]) {
			int nxt = it.first, w = it.second;
			if (!vis[nxt]) pq.push({ w, nxt });
		}
	}
	
	cout << ans;
	return 0;
}