#include <bits/stdc++.h>
using namespace std;

int N, par[1001];
struct P {
	int d, w;
	bool operator < (P& rhs) {
		return w > rhs.w;
	}
} a[1001];

int find(int a) {
	if (a == par[a]) return a;
	return par[a] = find(par[a]);
}

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
#endif
	ios_base::sync_with_stdio(false); cin.tie(0);

	cin >> N;
	for (int i = 0; i < N; i++)
		cin >> a[i].d >> a[i].w;

	iota(par, par + 1001, 0);

	sort(a, a + N);

	int ans = 0;
	for (int i = 0; i < N; i++) {
		int x = find(a[i].d);
		if (!x) continue;
		par[x] = x - 1;
		ans += a[i].w;
	}

	cout << ans;

	return 0;
}