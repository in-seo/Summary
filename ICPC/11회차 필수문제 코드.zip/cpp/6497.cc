#include <iostream>
#include <vector>
#include <algorithm>
#include <utility>
using namespace std;
typedef long long lint;
typedef pair<int, int> ii;
typedef pair<int, ii> pii;

int t, V, E;
int par[200000], Rank[200000];

void init() {
	for(int i = 0; i< 200000; i++) {
		par[i] = i; Rank[i] = 0;
	}
}

int find(int a) {
	if(par[a] == a) return a;
	return par[a] = find(par[a]);
}

void merge(int a, int b) {
	if((a = find(a))== (b = find(b))) return;
	if(Rank[a] < Rank[b]) par[a] = b;
	else {
		par[b] = a;
		if(Rank[a] == Rank[b]) Rank[b]++;
	}
}

int main() {
	while(1) {
		init();
		scanf("%d%d", &V, &E);
		if(!V && !E) break;
		vector<pii> g;
		lint f = 0;
		for(int i = 0; i<E; i++) {
			int u, v, w;
			scanf("%d%d%d", &u, &v, &w);
			g.push_back(pii(w, ii(u, v)));
			f += w;
		}
		sort(g.begin(), g.end());
		lint ans = 0, cnt = 0;
		for(int i = 0;; i++) {
			if(find(g[i].second.first) == find(g[i].second.second))
				continue;
			else ans += g[i].first;
			merge(g[i].second.first, g[i].second.second);
			if(++cnt == V-1) break;
		}
		printf("%lld\n", f - ans);
	}
	return 0;
}