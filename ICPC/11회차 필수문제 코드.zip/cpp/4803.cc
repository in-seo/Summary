#include <bits/stdc++.h>
using namespace std;

int N, M, par[505], vis[505];
int find(int a) {
	if (a == par[a]) return a;
	return par[a] = find(par[a]);
}

int mrg(int a, int b) {
	a = find(a), b = find(b);
	if (a == b) return vis[a] = vis[b] = 0;

	par[b] = a;
	return 1;
}

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
#endif
	ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	for (int tc = 1;; tc++) {
		int ans = 0;
		cin >> N >> M;
		if (!N && !M) break;
		assert(N != 0);
		iota(par, par + 505, 0);
		fill(vis, vis + 505, 1);
		

		while (M--) {
			int u, v; cin >> u >> v;
			mrg(min(u, v), max(u, v));
		}
		for (int i = 1; i <= N; i++)
			vis[find(i)] &= vis[i];

		for (int i = 1; i <= N; i++) {
			int x = find(i);
			if (x == i && vis[x]) ans++;
		}
		cout << "Case " << tc << ": ";
		if (ans == 0) cout << "No trees.\n";
		else if (ans == 1) cout << "There is one tree.\n";
		else cout << "A forest of " << ans << " trees.\n";
	}
	return 0;
}