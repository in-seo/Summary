#include <bits/stdc++.h>
using namespace std;

const int mxn = 1000100;
int N, M, par[mxn];

int find(int a) {
	if (par[a] == a) return a;
	else return par[a] = find(par[a]);
}

int mrg(int a, int b, int v = 0) {
	a = find(a), b = find(b);
	if (a == b) return 0;
	if (v) return 1;
	par[a] = b;
	return 1;
}

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
#endif
	ios_base::sync_with_stdio(false); cin.tie(0);

	cin >> N >> M;
	iota(par, par + N + 1, 0);
	while (M--) {
		int op, u, v;
		cin >> op >> u >> v;

		int f = mrg(u, v, op);
		if (op){
			if (!f) cout << "YES\n";
			else cout << "NO\n";
		}
	}
	return 0;
}