import sys
input = sys.stdin.readline

class DisjointSet:
    def __init__(self, n):
        self.parent = [0 for _ in range(n)]
        self.rank = [1 for _ in range(n)]
        for i in range(n):
            self.parent[i] = i

    def find(self, u):
        if u == self.parent[u]: return u
        self.parent[u] = self.find(self.parent[u])
        return self.parent[u]

    def merge(self, u, v):
        u = self.find(u)
        v = self.find(v)
        if u == v: return
        if self.rank[u] > self.rank[v]: u, v = v, u
        self.parent[u] = v
        if self.rank[u] == self.rank[v]: self.rank[v] += 1


MAX_V = 1001
V = 0
adj = [[] for _ in range(MAX_V)]

def kruskal(selected):
    ret = 0

    edges = []
    for u in range(V):
        for i in range(len(adj[u])):
            v, cost = adj[u][i]
            edges.append([cost, [u, v]])
    edges.sort()

    sets = DisjointSet(V)
    for i in range(len(edges)):
        cost, [u, v] = edges[i]
        if sets.find(u) == sets.find(v): continue

        sets.merge(u, v)
        selected.append([u, v])
        ret += cost
    
    return ret


n, m, k = map(int, input().split())
power = list(map(int, input().split()))
sum = 0

for i in range(1, k):
    adj[power[0]].append([power[i], 0])

for i in range(m):
    u, v, w = map(int, input().split())
    sum += w
    adj[u].append([v, w])

select = []
V = n + 1
print(kruskal(select))
