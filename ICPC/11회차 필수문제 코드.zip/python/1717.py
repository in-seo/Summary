import sys
input = sys.stdin.readline

class DisjointSet:
    def __init__(self, n):
        self.parent = [0 for _ in range(n)]
        self.rank = [1 for _ in range(n)]
        for i in range(n):
            self.parent[i] = i

    def find(self, u):
        if u == self.parent[u]: return u
        self.parent[u] = self.find(self.parent[u])
        return self.parent[u]

    def merge(self, u, v):
        u = self.find(u)
        v = self.find(v)
        if u == v: return
        if self.rank[u] > self.rank[v]: u, v = v, u
        self.parent[u] = v
        if self.rank[u] == self.rank[v]: self.rank[v] += 1

n, m = map(int, input().split())
ds = DisjointSet(n + 1)

for i in range(m):
    k, a, b = map(int, input().split())
    if k == 0:
        ds.merge(a, b)
    else:
        if ds.find(a) == ds.find(b):
            print("YES")
        else:
            print("NO")


