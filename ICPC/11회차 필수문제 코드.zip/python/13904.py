import sys, heapq
input = sys.stdin.readline

n = int(input())
v = [0 for _ in range(n)]
for i in range(n):
    v[i] = list(map(int, input().split()))

v.sort(reverse = True)
pq = []
ptr = 0
ans = 0
for i in range(1000, 0, -1):
    while ptr < len(v) and v[ptr][0] == i:
        heapq.heappush(pq, -v[ptr][1])
        ptr += 1
    if len(pq) == 0: continue
    ans += -heapq.heappop(pq)

print(ans)