import sys
input = sys.stdin.readline

class DisjointSet:
    def __init__(self, n):
        self.parent = [0 for _ in range(n)]
        self.rank = [1 for _ in range(n)]
        for i in range(n):
            self.parent[i] = i

    def find(self, u):
        if u == self.parent[u]: return u
        self.parent[u] = self.find(self.parent[u])
        return self.parent[u]

    def merge(self, u, v):
        u = self.find(u)
        v = self.find(v)
        if u == v: return
        if self.rank[u] > self.rank[v]: u, v = v, u
        self.parent[u] = v
        if self.rank[u] == self.rank[v]: self.rank[v] += 1


MAX_V = 200000
V = 0
adj = [[] for _ in range(MAX_V)]

def kruskal(selected):
    ret = 0

    edges = []
    for u in range(V):
        for i in range(len(adj[u])):
            v, cost = adj[u][i]
            edges.append([cost, [u, v]])
    edges.sort()

    sets = DisjointSet(V)
    for i in range(len(edges)):
        cost, [u, v] = edges[i]
        if sets.find(u) == sets.find(v): continue

        sets.merge(u, v)
        selected.append([u, v])
        ret += cost
    
    return ret



while True:
    m, n = map(int, input().split())
    if m == 0 and n == 0: break

    # init
    for i in range(MAX_V):
        adj[i] = []
    sum = 0


    for i in range(n):
        x, y, z = map(int, input().split())
        sum += z
        adj[x].append([y, z])

    V = m
    select = []
    print(sum - kruskal(select))
