#include <bits/stdc++.h>
using namespace std;

const int mxn = 200020;
int N, k, pos, v[mxn], used[mxn];

int below() {
	int kk = k;
	queue<int> q;
	if(pos * 2 <= N) q.push(pos * 2);
	if(pos * 2 + 1 <= N) q.push(pos * 2 + 1);

	while(!q.empty()) {
		int cur = q.front(); q.pop();
		if(++kk > N) return 0;

		v[cur] = kk, used[kk] = 1;
		if(cur * 2 <= N) q.push(cur * 2);
		if(cur * 2 + 1 <= N) q.push(cur * 2 + 1);
	}
	return 1;
}

int above() {
	int kk = k, cur = pos / 2;
	while(cur) {
		v[cur] = --kk;
		if(!kk) return 0;
		used[kk] = 1;
		cur /= 2;
	}
	return 1;
}

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
#endif
	ios_base::sync_with_stdio(false); cin.tie(0);
	cin >> N >> k >> pos;

	v[pos] = k, used[k] = 1;
	if(!below() || !above()) return cout << -1, 0;

	int val = 1;
	for(int i = 1; i <= N; i++) {
		while(used[val]) val++;
		if(!v[i]) v[i] = val++;
		cout << v[i] << '\n';
	}
	

	return 0;
}