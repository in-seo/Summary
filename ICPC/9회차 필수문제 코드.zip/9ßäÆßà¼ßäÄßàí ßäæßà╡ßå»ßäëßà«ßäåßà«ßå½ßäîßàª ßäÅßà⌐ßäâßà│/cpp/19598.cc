#include <bits/stdc++.h>
using namespace std;
using ii = pair<int, int>;

int N;
priority_queue<ii> pq;
ii a[100010];
int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
#endif
	ios_base::sync_with_stdio(false); cin.tie(0);
	cin >> N;

	for(int i = 0; i < N; i++)
		cin >> a[i].first >> a[i].second;

	sort(a, a + N);

	for(int i = 0; i < N; i++) {
		int nxtroom = (int)pq.size()+1;
		if(!pq.empty() && -pq.top().first <= a[i].first)
			pq.pop();
		pq.push({ -a[i].second, -a[i].first });
	}

	cout<<(int)pq.size();

	return 0;
}