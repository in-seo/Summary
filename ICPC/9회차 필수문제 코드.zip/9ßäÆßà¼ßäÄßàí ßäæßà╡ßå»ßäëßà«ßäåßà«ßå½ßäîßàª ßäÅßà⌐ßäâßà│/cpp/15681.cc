#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

int N, rt, Q, sz[100010];
vector<int> adj[100010];

int dfs(int cur, int prv = -1) {
	int ret = 1;
	for (int&nxt : adj[cur]) {
		if (nxt == prv) continue;
		ret += dfs(nxt, cur);
	}

	return sz[cur] = ret;
}

int main() {
	//freopen("input.txt", "r", stdin);
	scanf("%d%d%d", &N, &rt, &Q);
	for (int i = 1; i < N; i++) {
		int u, v;
		scanf("%d%d", &u, &v);
		adj[u].push_back(v);
		adj[v].push_back(u);
	}
	dfs(rt);
	while (Q--) {
		int x; scanf("%d", &x);
		printf("%d\n", sz[x]);
	}

	return 0;
}