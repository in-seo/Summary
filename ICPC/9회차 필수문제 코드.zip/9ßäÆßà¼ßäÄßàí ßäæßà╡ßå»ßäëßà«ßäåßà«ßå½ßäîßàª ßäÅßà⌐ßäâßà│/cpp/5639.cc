#include <stdio.h>
#include <vector>
using namespace std;

int arr[16385], n;

void postorder(int s, int e) {
	if (s == e) return;
	if (s + 1 == e) {
		printf("%d\n", arr[s]);
		return;
	}
	
	int right = s + 1;
	for (; right < e && arr[s] > arr[right]; right++);
	postorder(s+1, right);
	postorder(right, e);
	printf("%d\n", arr[s]);
}

int main() {
	for (; scanf("%d", arr + n) > 0; n++);

	postorder(0, n);

	return 0;
}