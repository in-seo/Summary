#include <bits/stdc++.h>
using namespace std;
using ii = pair<int, int>;

int N, M;

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
#endif
	ios_base::sync_with_stdio(false); cin.tie(0);

	cin >> N >> M;

	vector<ii> res;
	for (int i = 0; i < M - 1; i++)
		res.push_back({ M - 1, i });
	for (int i = M; i < N; i++)
		res.push_back({ i - 1, i });

	for (auto &x : res)
		cout << x.first << ' ' << x.second<<'\n';
	

	return 0;
}