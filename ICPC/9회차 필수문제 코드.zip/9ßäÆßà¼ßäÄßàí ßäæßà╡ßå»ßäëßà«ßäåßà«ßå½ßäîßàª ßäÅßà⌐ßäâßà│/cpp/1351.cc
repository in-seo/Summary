#include <stdio.h>
#include <map>
using namespace std;
typedef long long lint;

lint N, P, Q;
map<lint, lint> mp;

lint go(lint n) {
	//lint &ret = mp[n];
	if (mp.find(n) != mp.end()) return mp[n];
	return mp[n] = go(n / P) + go(n / Q);
}
int main() {
	scanf("%lld%lld%lld", &N, &P, &Q);
	mp[0] = 1;
	printf("%lld\n", go(N));
	return 0;
}