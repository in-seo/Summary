import sys
import heapq
input = sys.stdin.readline

n = int(input())
l = []

for _ in range(n):
    l.append(list(map(int, input().split())))
    
l.sort()

pq = []
heapq.heappush(pq, l[0][1])
ans = 1
for i in range(1, n):
    while 0 < len(pq) and pq[0] <= l[i][0]:
        heapq.heappop(pq)
    heapq.heappush(pq, l[i][1])
    ans = max(ans, len(pq))

print(ans)