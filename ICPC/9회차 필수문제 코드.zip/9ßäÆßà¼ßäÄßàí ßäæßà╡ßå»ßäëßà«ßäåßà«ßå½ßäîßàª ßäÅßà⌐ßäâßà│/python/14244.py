n, m = map(int, input().split())

for i in range(1, n - m + 1):
    print(i - 1, i)

for i in range(n - m + 1, n):
    print(n - m, i)