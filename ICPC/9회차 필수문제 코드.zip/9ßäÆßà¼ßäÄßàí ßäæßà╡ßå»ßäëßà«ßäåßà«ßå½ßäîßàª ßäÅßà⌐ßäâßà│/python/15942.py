n = int(input())
k, p = map(int, input().split())

ans = [0 for _ in range(1000000)]
chk = [False for _ in range(1000000)]
up = 0 # 부모 노드의 수
down = 0 # 자식 노드의 수

# p번째에 k 값이 들아갈 때 p번째 노드의 모든 부모 노드를 채웁니다.
i = p // 2
up = 0
while  0 < i:
    up += 1
    ans[i] = up
    chk[up] = True
    i //= 2

# p번째 노드를 포함한 p번째 노드의 모든 자식 노드를 채웁니다.
val = k
def solve(now):
    global down, val
    if n < now: return
    ans[now] = val
    chk[val] = True
    val += 1
    down += 1
    solve(now * 2)
    solve(now * 2 + 1)

solve(p)


# 나머지 노드를 채웁니다.
val = 1
for i in range(1, n + 1):
    while chk[val] == True:
        val +=1
    if ans[i] == 0:
        ans[i] = val
        val += 1


# 출력
if up < k and down + k <= n + 1:
    for i in range(1, n + 1):
        print(ans[i], end=" ")
    print()
else:
    print(-1)

