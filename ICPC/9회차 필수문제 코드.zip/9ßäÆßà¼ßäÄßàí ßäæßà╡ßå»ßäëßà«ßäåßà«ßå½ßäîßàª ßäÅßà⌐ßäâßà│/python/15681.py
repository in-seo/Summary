import sys
input = sys.stdin.readline
sys.setrecursionlimit(1000000)

n, r, q = map(int, input().split())
adj = [[] for _ in range(100001)]
ans = [0 for _ in range(100001)]

def search(cur, par):
    sum = 0
    for nxt in adj[cur]:
        if nxt == par: continue
        sum += search(nxt, cur)
    ans[cur] = sum + 1
    return ans[cur]


for i in range(n - 1):
    u, v = map(int, input().split())
    adj[u].append(v)
    adj[v].append(u)

search(r, -1)

for i in range(q):
    tmp = int(input())
    print(ans[tmp])
