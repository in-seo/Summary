def a(i):
    if i == 0: 
        return 1
    if i in dic: 
        return dic[i]
    
    dic[i] = a(i // p) + a(i // q)
    return dic[i]

n, p, q = map(int, input().split())
dic = {}

print(a(n))
