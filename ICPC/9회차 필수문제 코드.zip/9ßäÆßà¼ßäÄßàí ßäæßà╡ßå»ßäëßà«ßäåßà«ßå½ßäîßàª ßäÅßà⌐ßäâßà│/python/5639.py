import sys
sys.setrecursionlimit(10005)

class Node(object):
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None

def insert(node, data):
    if node == None:
        node = Node(data)
    elif data < node.data:
        node.left = insert(node.left, data)
    else:
        node.right = insert(node.right, data)
    return node

def postorder(node):
    if node.left != None:
        postorder(node.left)
    if node.right != None:
        postorder(node.right)
    print(node.data)


root = None
while True:
    try:
        n = int(input())
        root = insert(root, n)

    except EOFError:
        break    

postorder(root)